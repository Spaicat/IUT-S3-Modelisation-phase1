package alaminesimulateur;

/**
 *
 * @author Thibault
 */
public class ALaMineSimulateur {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Gimli gimli = new Gimli();
        gimli.start();
    }

}
